# BigFont
Arduino library to display large numbers on 4 row, character type LCD

The library consists of two functions, loadchars() and printbigchar().  
   loadchars() programs the LCD controller with 7 special characters
   printbigchar() prints a single digit 4 rows high and 5 col wide 
